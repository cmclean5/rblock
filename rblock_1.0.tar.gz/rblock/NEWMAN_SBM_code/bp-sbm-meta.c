/* Program to perform the full two-group EM/BP calculation using the
 * standard SBM on an arbitrary network read from a file
 *
 * Written by Mark Newman  21 NOV 2014
 * Modified to include enumerative metadata stored in the "label" field of
 *   the network structure  23 NOV 2014
 */

/* Program control */

#define DEBUG
#undef VERBOSE

/* Inclusions */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <time.h>
#include <gsl/gsl_rng.h>

#include "readgml.h"

/* Constants */

/* Globals */

NETWORK G;
int *x;          // Metadata numbers
int *nx;         // Number in each metadata group
char **mlabel;   // Metadata labels
int nmlabels;    // Number of distint metadata values

double *gamma1;          // Parameters
double c_11,c_12,c_22;
double p_11,p_12,p_22;

double **eta;    // Messages
double *q;       // One-point marginals

gsl_rng *rng;


/* Get metadata from the labels */

#define MAXMETA 100

void get_metadata()
{
  int u,i;

  /* Make space for the metadata numbers and labels */

  x = malloc(G.nvertices*sizeof(int));
  mlabel = malloc(MAXMETA*sizeof(char*));
  nmlabels = 0;

  /* Go through the vertices */

  for (u=0; u<G.nvertices; u++) {

    /* Check to see if this label is already in the list of labels */

    for (i=0; i<nmlabels; i++) {
      if (strcmp(G.vertex[u].label,mlabel[i])==0) break;
    }

    /* If not, add it */

    if (i==nmlabels) {
      mlabel[nmlabels++] = G.vertex[u].label;  // Just set pointers equal
    }

    /* Store this as the label type for this vertex */

    x[u] = i;
  }

  /* Count how many there in each group */

  nx = calloc(nmlabels,sizeof(int));
  for (u=0; u<G.nvertices; u++) nx[x[u]]++;
}


/* Do BP */

void bp()
{
  int i,j;
  int u,v;
  double logpre;
  double delta,maxdelta;
  double neweta;
  double logq;
  double **logeta;

  /* Make space for the logs-odds ratios of the messages.  These respresent
   * the log of the ratio of the probability of being in group 1 and group 2
   */

  logeta = malloc(G.nvertices*sizeof(double*));
  for (u=0; u<G.nvertices; u++) {
    logeta[u] = malloc(G.vertex[u].degree*sizeof(double));
  }

  /* Main BP loop */

#define BP_ACC 1e-6

  do {
  
    /* Calculate the log-prefactor */

    logpre = 1.0;
    for (u=0; u<G.nvertices; u++) logpre += log1p(-q[u]*(p_11-p_12)-p_12)
			                    - log1p(-q[u]*(p_12-p_22)-p_22);

    /* Calculate new values for the one-vertex marginals */

    for (u=0; u<G.nvertices; u++) {
      logq = log(gamma1[x[u]]/(1-gamma1[x[u]]))*logpre;
      for (i=0; i<G.vertex[u].degree; i++) {
	logq += log(eta[u][i]*(p_11-p_12)+p_12)
	        - log(eta[u][i]*(p_12-p_22)+p_22);
      }
      q[u] = 1/(1+exp(-logq));
    }

    /* Calculate new values for the logs of the messages */

    for (u=0; u<G.nvertices; u++) {
      for (i=0; i<G.vertex[u].degree; i++) {
	v = G.vertex[u].edge[i].target;
	logeta[u][i] = log(gamma1[x[v]]/(1-gamma1[x[v]]))*logpre;
	for (j=0; j<G.vertex[v].degree; j++) {
	  if (G.vertex[v].edge[j].target!=u) {
	    logeta[u][i] += log(eta[v][j]*(p_11-p_12)+p_12)
                          - log(eta[v][j]*(p_12-p_22)+p_22);
	  }
	}
      }
    }

    /* Calculate the messages themselves and the maximum change */

    maxdelta = 0.0;
    for (u=0; u<G.nvertices; u++) {
      for (i=0; i<G.vertex[u].degree; i++) {
	neweta = 1/(1+exp(-logeta[u][i]));
	delta = fabs(neweta-eta[u][i]);
	if (delta>maxdelta) maxdelta = delta;
	eta[u][i] = neweta;
      }
    }

    fprintf(stderr,"Max change = %g        \r",maxdelta);

  } while (maxdelta>BP_ACC);

  fprintf(stderr,"\n");

  /* Free up space */

  for (u=0; u<G.nvertices; u++) free(logeta[u]);
  free(logeta);
}



#define EM_ACC 1e-6

main(int argc, char *argv[])
{
  int u,v;
  int i,j;
  int twom;
  double n1,n2;
  double c;
  double term_11,term_12,term_21,term_22;
  double norm;
  double sum_11,sum_12,sum_22;
  double oldgamma,deltagamma;
  double *n1x;
  double L;

  // Initialize random number generator

  rng = gsl_rng_alloc(gsl_rng_mt19937);
  gsl_rng_set(rng,time(NULL));

  // Read the network from stdin

  read_network(&G,stdin);
  for (u=twom=0; u<G.nvertices; u++) twom += G.vertex[u].degree;
  c = (double)twom/G.nvertices;
  get_metadata();

  // Make space for the messages and marginals, and initialize both to
  // random initial values

  eta = malloc(G.nvertices*sizeof(double*));
  q = malloc(G.nvertices*sizeof(double));
  for (u=0; u<G.nvertices; u++) {
    eta[u] = malloc(G.vertex[u].degree*sizeof(double));
    for (i=0; i<G.vertex[u].degree; i++) eta[u][i] = gsl_rng_uniform(rng);
    q[u] = gsl_rng_uniform(rng);
  }
  n1x = malloc(nmlabels*sizeof(double));

  // Choose random initial values for the parameters gamma,c

  gamma1 = malloc(nmlabels*sizeof(double));
  for (i=0; i<nmlabels; i++) gamma1[i] = gsl_rng_uniform(rng);

  c_11 = c*gsl_rng_uniform(rng);
  c_12 = c*gsl_rng_uniform(rng);
  c_22 = c*gsl_rng_uniform(rng);

/*   for (i=0; i<nmlabels; i++) gamma1[i] = 0.5; */

/*   c_11 = c_22 = 10.0; */
/*   c_12 = 2.0; */

  p_11 = c_11/G.nvertices;
  p_12 = c_12/G.nvertices;
  p_22 = c_22/G.nvertices;

  // EM loop

  do {

    // Run BP to calculate the messages and one-vertex marginals

    bp();

    // Calculate the new values of the gammas

    for (i=0; i<nmlabels; i++) n1x[i] = 0.0;
    for (u=n1=0; u<G.nvertices; u++) {
      n1 += q[u];
      n1x[x[u]] += q[u];
    }
    n2 = G.nvertices - n1;

    oldgamma = gamma1[0];
    for (i=0; i<nmlabels; i++) gamma1[i] = n1x[i]/nx[i];
    deltagamma = fabs(gamma1[0]-oldgamma);

    // Calculate the new values of the p's

    sum_11 = sum_12 = sum_22 = 0.0;
    for (u=0; u<G.nvertices; u++) {
      for (i=0; i<G.vertex[u].degree; i++) {
	v = G.vertex[u].edge[i].target;

	// Find which edge leads back from v to u

	for (j=0; j<G.vertex[v].degree; j++) {
	  if (G.vertex[v].edge[j].target==u) break;
	}
	if (j==G.vertex[v].degree) {
	  fprintf(stderr,"Error!\n");
	  exit(23);
	}

	// Calculate the terms and the normalization factor

	term_11 = p_11*eta[u][i]*eta[v][j];
	term_12 = p_12*eta[u][i]*(1-eta[v][j]);
	term_21 = p_12*(1-eta[u][i])*eta[v][j];
	term_22 = p_22*(1-eta[u][i])*(1-eta[v][j]);
	norm = term_11 + term_12 + term_21 + term_22;

	// Add to the running sums

	sum_11 += term_11/norm;
	sum_12 += term_12/norm;
	sum_22 += term_22/norm;
      }
    }

    // Calculate the new values of the p variables

    p_11 = sum_11/(n1*n1);
    p_12 = sum_12/(n1*n2);
    p_22 = sum_22/(n2*n2);

    c_11 = p_11*G.nvertices;
    c_12 = p_12*G.nvertices;
    c_22 = p_22*G.nvertices;

    // Print out the new values of the parameters

    for (i=0; i<nmlabels; i++) printf("gamma1[%i] = %g\n",i,gamma1[i]);
    printf("c_11,c_12,c_22 = %g, %g, %g\n",c_11,c_12,c_22);

  } while (deltagamma>EM_ACC);

  // Calculate the expected log-likelihood

  // Internal energy first

  L = n1*n1*(p_11*log(p_11) + (1-p_11)*log(1-p_11))
    + 2*n1*n2*(p_12*log(p_12) + (1-p_12)*log(1-p_12))
    + n2*n2*(p_22*log(p_22) + (1-p_22)*log(1-p_22));

  for (i=0; i<nmlabels; i++) {
    L += nx[i]*(gamma1[i]*log(gamma1[i]) + (1-gamma1[i])*log(1-gamma1[i]));
  }

  // Now the entropy, which is approximated as the 1-vertex value

  for (u=0; u<G.nvertices; u++) {
    L -= q[u]*log(q[u]) + (1-q[u])*log(1-q[u]);
  }

  printf("Log-likelihood = %g\n",L);
}
