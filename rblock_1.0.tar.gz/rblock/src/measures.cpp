#include "measures.h"

measures::measures(){ setup(); }

measures::measures(network *gg){

  setup();
  this->gg   = gg;
  this->N    = gg->getN();
  this->M    = gg->getM();
  this->el   = gg->getEdgeList();
  this->El   = gg->getelSize();

  for( int i=0; i<N; i++ ) this->twom += gg->V[i].degree;
  
}

measures::measures(network *gg, int K){

  setup();
  this->gg   = gg;
  this->N    = gg->getN();
  this->M    = gg->getM();
  this->K    = (K > 0) ? K : 1;
  this->el   = gg->getEdgeList();
  this->El   = gg->getelSize();

  for( int i=0; i<N; i++ ) this->twom += gg->V[i].degree;
  
}

void measures::setup(){

  this->gg   =0;
  this->N    =0;
  this->M    =0;
  this->K    =1;

  this->el   =0;
  this->El   =0;

  this->twom =0;
  
  this->qz   =0;
  this->seed =0;
  this->g=0;

  this->MAXEXPO=700;
  
  assignSpace();
  
}

void measures::assignSpace(){

  //---set gsl random number generator, using taus2 generator
  //g = gsl_rng_alloc(gsl_rng_taus2);
  g = gsl_rng_alloc(gsl_rng_mt19937);  
  
}

void measures::freeSpace(){

  if( g!=0 ){ gsl_rng_free(g); }

}

measures::~measures(){ freeSpace(); }


//---Initialize random seed:
void measures::setSeed (bool useSeed, int newSeed ){

  if( useSeed==true ){
    seed = (unsigned long int) newSeed;
  } else {
    seed = (unsigned long int) time(NULL);
  }

  gsl_rng_set(g , seed);

}


unsigned long int measures::getSeed(){ return seed; }


//---Function to generate d numbers at random that add up to unity
void measures::random_unity(int d, double *xx){
  int k;
  double sum=0.0;

  for (k=0; k<d; k++) {
    xx[k] = 0.0;
    xx[k] = gsl_rng_uniform(g);
    sum += xx[k];
  }
  for (k=0; k<d; k++) xx[k] /= sum;
}

//---Function to generate d random numbers
void measures::random_vec(int d, double *xx){
  int k;

  for (k=0; k<d; k++) {
    xx[k] = 0.0;
    xx[k] = gsl_rng_uniform(g);
  }

}

int measures::getTwom(){

  return twom;
  
}


void measures::bridgeness(){

  int i,k;

  for(i=0; i<N; i++){

    double b=0.0;

    for(k=0; k<K; k++){                                                       
      b  += (gg->V[i].Kprobs[k] - 1.0/(double)K) * (gg->V[i].Kprobs[k] - 1.0/(double)K);
}                     
                         
    gg->V[i].bridge  = 1.0 - sqrt((double)K/((double)K - 1.0) *  b);   
                        
  }

}

/*
Y. Ahn, J. Bagrow, S. Lehmann. Link communities reveal multiscale complexity in networks, Nature Letters, 15 August 2010.
*/
void measures::partitionDensity(double &PD){

  int v,k,m;
  
  double mc = 0.0;
  double nc = 0.0;
  PD        = 0.0;    
  for(k=0; k<K; k++){
      
    mc = 0.0;
    nc = 0.0;
    
    for(v=0; v<N; v++) nc += (double)gg->V[v].Kprobs[k];

    for(m=0; m<M; m++) mc += qz[m][k];      
    
    PD += ( mc - (nc - 1)/nc*(nc-1)/2-(nc-1) );
    
  }

}

// entropy function
// -1.0*x*log(x)
double measures::entropy( double x ){

  if( x == 0 ) return 0;
  else return -1.0*(x*log(x));
  
}

// binary Entropy function
// -1.0*(x*log(x) + (1-x)*log(1-x)), or
// -x*log(x) - (1-x)*log(1-x)
double measures::binaryEntropy( double x ){

  return (entropy(x) + entropy(1-x));
  
}


//return log gamma of n
double measures::loggamma( int Nn ){

  return gsl_sf_lnfact( (const unsigned int)Nn );
  
}

//multiset coefficient
double measures::multico( int Nn, int Kk ){

  return binco( (Nn+Kk-1), Kk );
  
}

//binomial coefficient
double measures::binco( int Nn, int Kk ){

  double result, temp, num, dem;
  
  result = 0.0; num = 0.0; dem = 0.0; temp = 0.0;

  num = gsl_sf_lnfact( (const unsigned int)Nn );
 
  dem = gsl_sf_lnfact( (const unsigned int)Kk ) +
        gsl_sf_lnfact( (const unsigned int)(Nn-Kk) );
 
  temp = num - dem;
  
  if( fabs(temp) > MAXEXPO ){
    temp > 0 ? result = exp( MAXEXPO ) : result = exp( -MAXEXPO );
  } else {  
    result = exp( temp ) ;
  }    
  
  return result;
  
}

void measures::min(int d, double *xx, double &min){

  int i;
  min = xx[0];
  for(i=0; i<d; i++){
    if( xx[i] < min ) min = xx[i];
  }
  
}

void measures::max(int d, double *xx, double &max){

  int i;
  max = xx[0];
  for(i=0; i<d; i++){
    if( xx[i] > max ) max = xx[i];
  }
  
}

/*
void measures::bernstein_polynomial( int N, int j, double x, double &result ){

  double bico;

  result = -1; bico = 0.0;

  if( (x < 0) || (x > 1) ){ return; }

  if( (j < 0) || (j > N) ){ return; }

  bico = binco( N, j );

  result = bico * pow( x, j ) * pow( (1-x), (N-j) );

}
*/
